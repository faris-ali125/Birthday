# Happy Birthday Celebration Animation
This project is a simple web page that creates a birthday celebration animation using HTML, CSS and JavaScript.

## Overview
The animation includes:

- Turning on colorful bulbs
- Playing a birthday song
- Releasing flying balloons
- Displaying a cake with candles
- Lighting the candles
- Showing a birthday wish message
- Unfolding a birthday story
  
## Technologies Used
HTML
CSS
JavaScript (jQuery)
Getting Started
Clone this repository:

Website - [Happy Birthday](https://github.com/nafisalawalidris/Happy-Birthday.git)

An easy to deploy, Happy Birthday animation design TEMPLATE.

View Deployments [here]([https://github.com/Rishabh04-02/happy-birthday/deployments])
